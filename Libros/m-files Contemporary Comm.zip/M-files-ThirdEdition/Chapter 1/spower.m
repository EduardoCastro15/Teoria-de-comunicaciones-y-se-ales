function p=spower(x)
%       p=spower(x)
%SPOWER     returns the power in signal x
p=(norm(x)^2)/length(x);
