function cplotask(M)

figure;

modmap('ask',M);


