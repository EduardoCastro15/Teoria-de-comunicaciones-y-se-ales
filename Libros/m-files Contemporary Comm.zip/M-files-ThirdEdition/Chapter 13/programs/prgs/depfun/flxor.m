function z = flxor(x,y)
%FLXOR Perform integer exclusive OR (XOR) computation.
%
%WARNING: This is an obsolete function and may be removed in the future.
%         Please use BITXOR instead.

%   FLXOR(X,Y) returns bit-wise exclusive OR computation
%   between the two integers X and Y.
%
%   See also GFPLUS. BITXOR

%   Copyright 1996-2001 The MathWorks, Inc.
%   $Revision: 1.12 $

