function cplotpsk(M)

figure;

modmap('psk',M);


