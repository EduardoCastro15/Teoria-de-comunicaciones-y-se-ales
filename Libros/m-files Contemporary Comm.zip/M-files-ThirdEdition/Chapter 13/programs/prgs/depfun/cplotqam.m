function cplotqam(M)

figure;

modmap('qam',M);


