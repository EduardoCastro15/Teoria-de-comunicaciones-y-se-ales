if figflag('Tutorial')
    delete(gcf);
end

DigModTutorial