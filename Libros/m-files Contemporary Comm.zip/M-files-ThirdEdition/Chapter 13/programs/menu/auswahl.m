%asks for pulse shape and receive filter and starts the simulink program

function auswahl(modverf)

global name;
name=modverf;

pulsemenu;


