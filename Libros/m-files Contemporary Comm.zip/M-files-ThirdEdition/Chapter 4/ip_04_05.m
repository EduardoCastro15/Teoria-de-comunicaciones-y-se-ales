% MATLAB script for Illustrative Problem 4.5.
a=[-10 -5 -4 -2 0 1 3 5 10];
[y,dist]=mse_dist('normal',a,1e-6,0,1)