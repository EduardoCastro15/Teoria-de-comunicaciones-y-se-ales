% MATLAB script for Illustrative Problem 4.7.
p1=0;
p2=1;
delta=1;
n=11;
tol=0.01;
b=10*p2;
uq_mdpnt('normal',b,n,delta,tol,p1,p2)