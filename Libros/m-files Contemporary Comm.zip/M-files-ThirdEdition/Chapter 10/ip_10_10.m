% MATLAB script for Illustrative Problem 10.10.
[p_err_ha,gamma_b]=p_e_hd_a(10,16,11,15,3);
semilogy(gamma_b,p_err_ha)
