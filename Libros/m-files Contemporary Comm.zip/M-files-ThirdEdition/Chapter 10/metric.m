function distance=metric(x,y)
if x==y
  distance=0;
else
  distance=1;
end